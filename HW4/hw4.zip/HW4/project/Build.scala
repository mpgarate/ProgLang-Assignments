import sbt._
import Keys._

object HW4Build extends Build {
  lazy val root = Project(id = "hw4",
                          base = file("."))


}
